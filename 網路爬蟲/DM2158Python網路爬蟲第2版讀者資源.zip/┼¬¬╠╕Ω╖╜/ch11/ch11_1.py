# ch11_1.py
import sqlite3
conn = sqlite3.connect("myData.db")
conn.close()








