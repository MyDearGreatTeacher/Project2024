# ch7_1.py
from selenium import webdriver

browser = webdriver.Firefox()
print(type(browser))

            

