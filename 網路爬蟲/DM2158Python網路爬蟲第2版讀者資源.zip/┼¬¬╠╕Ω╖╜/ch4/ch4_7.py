# ch4_7.py
import pandas as pd

s6 = pd.Series(9, index=[1, 2, 3])
print(f"{s6}")



      






















