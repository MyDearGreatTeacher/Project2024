# ch4_6.py
import pandas as pd

fruits = ['Orange', 'Apple', 'Grape']
price = [30, 50, 40]
s5 = pd.Series(price, index=fruits)
print(f"{s5}")



      






















