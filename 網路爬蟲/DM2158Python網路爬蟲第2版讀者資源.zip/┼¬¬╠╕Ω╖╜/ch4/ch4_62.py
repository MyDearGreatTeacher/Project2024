# ch4_62.py
from datetime import datetime

timeStop = datetime(2022,12,11,19,50,50)
while datetime.now() < timeStop:
    print("Program is sleeping.", end="")
print("Wake up")




















