# ch4_1.py
import pandas as pd

s1 = pd.Series([11, 22, 33, 44, 55])
print(s1)






















