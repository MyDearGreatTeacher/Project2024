# ch4_30.py
import pandas as pd
import numpy as np

s = pd.Series([1, 2, 3])
x = np.square(s)
print(x)















