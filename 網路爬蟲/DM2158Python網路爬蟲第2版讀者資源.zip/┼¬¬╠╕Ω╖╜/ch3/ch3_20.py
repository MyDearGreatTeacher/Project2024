# ch3_20.py
import urllib.request

url_pict = 'https://baidu.com/img/bd_logo1.png'
fn = 'baidu.png'
pict = urllib.request.urlretrieve(url_pict,fn)







