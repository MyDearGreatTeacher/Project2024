# ch3_26.py
from urllib import parse

query_str = 'q=parse&check_keywords=yes&area=default'
print('parse.parse_qs  = ', parse.parse_qs(query_str))
print('parse.parse_qsl = ', parse.parse_qsl(query_str))








    












