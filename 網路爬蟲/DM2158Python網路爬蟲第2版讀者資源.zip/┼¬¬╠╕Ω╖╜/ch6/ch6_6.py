# ch6_6.py
import hashlib

print(hashlib.algorithms_guaranteed)         # 列出跨平台可使用的哈希演算法









