# 第六章/multiple_page_prj/home.py
import streamlit as st

st.title("这里是主页")
st.write("这个页面来自home.py文件，你可点击左侧👈的页面，导航到相应的页面")

st.write("这是一个多页面的Web应用，在本应用中你可以学到三个库的基本使用")
