# 第七章/help_streamlit.py
import streamlit as st

st.title('显示Strealit库的帮助信息')
# 不设置obj参数
st.help()
