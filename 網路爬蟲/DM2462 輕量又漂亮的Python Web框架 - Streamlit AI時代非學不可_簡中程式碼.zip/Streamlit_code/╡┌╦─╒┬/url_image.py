import streamlit as st

st.text("传入URL，然后使用st.image()方法进行展示")
st.image("https://wangxhub.com/wp-content/uploads/2023/07/bird.jpg", caption='小鸟')
