# 第四章/crop_image.py
import streamlit as st
from PIL import Image

original_image = Image.open("狗.jpg")
# 展示原始图像
st.title("原始图像")
st.image(original_image)
st.write('原始图片的图像大小：', original_image.size)
# 裁剪图像
crop_image = original_image.crop((50, 50, 200, 200))
# 展示裁剪后的图像
st.title("裁剪图像")
st.image(crop_image)
st.write('裁剪后的图像大小：', crop_image.size)
