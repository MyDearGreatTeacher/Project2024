import streamlit as st

images = ["鱼.jpg", "猫.jpg", "天鹅.jpg"]

st.subheader("展示多个图片")
st.image(images)
