import streamlit as st

st.write('这是我的第一个Streamlit应用, Hello World。')
