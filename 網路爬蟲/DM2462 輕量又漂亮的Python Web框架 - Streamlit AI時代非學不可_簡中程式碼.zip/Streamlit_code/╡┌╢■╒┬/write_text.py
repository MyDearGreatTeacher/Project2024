import streamlit as st  # 导入Streamlit并用st代表它

# markdown格式的文本
st.write('你好，_Streamlit_！你非常*实用*:+1:')
