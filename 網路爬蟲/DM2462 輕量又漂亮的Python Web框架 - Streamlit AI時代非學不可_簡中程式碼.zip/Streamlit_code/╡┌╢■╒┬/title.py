# 第二章/title.py
import streamlit as st   # 导入Streamlit并用st代表它
# 这里为了演示创建了多个标题展示元素

# 创建一个标题展示元素，内容是全英文的，默认锚点为first-title
st.title("first title")

# 创建一个标题展示元素，内容是全中文的
# 如不定义anchor参数，则无锚点
st.title("标题")

# 创建一个标题展示元素，内容是中英文混杂的
# 默认的锚点是英文部分的，即chinese
st.title("这是chinese标题")

# 第四个标题展示元素,并增加了锚点
st.title('这是第四个标题',anchor='fourth')

# 第五个标题展示元素,并增加了锚点和工具提示
st.title('这是第五个标题',anchor='fifth', help='工具提示')

# 第六个标题展示元素,内容使用了Markdown语法和表情符号,并增加了锚点和工具提示
st.title('这是第*六*个标题 :sunglasses:',anchor='sixth')
